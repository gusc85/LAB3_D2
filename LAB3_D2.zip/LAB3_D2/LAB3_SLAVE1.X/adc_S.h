#ifndef ADC_S_H
#define ADC_S_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h>

//******************************************************************************
//  Funcion para inicializar los canales
//******************************************************************************
void adc_init(int channel);

//******************************************************************************
//  Funcion para leer los canales
//******************************************************************************
int adc_read(void);

//******************************************************************************
//  Funcion para cambiar los canales
//******************************************************************************
void adc_change_channel(int channel);

//******************************************************************************
//  Funcion para pedir los canales
//******************************************************************************
int adc_get_channel(void);

#endif	/* ADC_H */
