#ifndef INT_H
#define INT_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h>

//******************************************************************************
//  Funcion para configurar los botones en puerto B
//******************************************************************************
void ioc_init(char pin);

#endif	/* INTERRUPCIONES_H */

