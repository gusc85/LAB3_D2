#ifndef MAPEO_H
#define	MAPEO_H

#include <xc.h> 

float mapRange(char input, char inputMin, char inputMax, char outputMin, float outputMax);

#endif	/* MAP_H */